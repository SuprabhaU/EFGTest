//
//  ProductView.swift
//  EDGTest
//
//  Created by Suprabha Dhavan on 17/05/23.
//

import SwiftUI

struct ProductView: View {
    var body: some View {
        NavigationView{
            List(0..<menuItems.count) { item in
                HStack {
                    HStack{
                        AsyncImage(url: URL(string: menuItems[item].imageURL)) { image in
                            image
                                .resizable()
                                .scaledToFill()
                        } placeholder: {
                            ProgressView()
                        }
                        .frame(width: 44, height: 44)
                        .background(Color.gray)
                        .clipShape(Circle())
                        Text(verbatim: menuItems[item].title)
                        Text(verbatim: String(format: "%.2f", menuItems[item].price)).foregroundColor(Color.brown)
                        Button("Add to cart") {
                            print("Button tapped!")
                        }
                        Spacer()
                    }
                    VehicleCell(vehicle: menuItems[item])
                }.navigationBarTitle(Text("Products"))
            }
        }
        }
}

struct ProductView_Previews: PreviewProvider {
    static var previews: some View {
        ProductView()
    }
}
struct VehicleCell: View {
    let vehicle: Vehicle
    var body: some View {
        let localizzedkey = LocalizedStringKey("")
        return NavigationLink(localizzedkey, destination: DetailView(name: vehicle.title, image: vehicle.imageURL))
    }
}
