//
//  EDGTestApp.swift
//  EDGTest
//
//  Created by Suprabha Dhavan on 17/05/23.
//

import SwiftUI

@main
struct EDGTestApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView(dish: menuItems[0])
//            ContentView()
//                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
