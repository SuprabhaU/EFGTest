//
//  DetailView.swift
//  EDGTest
//
//  Created by Suprabha Dhavan on 17/05/23.
//

import SwiftUI

struct DetailView: View {
    var name: String
    var image: String
    @StateObject var globalString = GlobalString()
    @State var globalString1 = [String]()
    var body: some View {
        HStack{
            AsyncImage(url: URL(string: image)) { image in
                image
                    .resizable()
                    .scaledToFill()
            } placeholder: {
                ProgressView()
            }
            .frame(width: 44, height: 44)
            .background(Color.gray)
            .clipShape(Circle())
            Text(verbatim: name)
            Button("Favourite") {
                globalString.usedWords.append(name)
                globalString1 = globalString.usedWords
                FavView(globalString1:self.$globalString1)
            }
            Spacer()
        }.padding().navigationBarTitle(Text(name), displayMode: .inline)
        }
}

struct DetailView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        DetailView(name: "name", image: "image")
    }
}
