//
//  FavView.swift
//  EDGTest
//
//  Created by Suprabha Dhavan on 17/05/23.
//

import SwiftUI

struct FavView: View {
    @Binding var globalString1: [String]
    var body: some View {
        let _ = print(globalString1)
        List(0..<globalString1.count) { item in
            HStack {
                HStack{
                    
                    Text(verbatim: globalString1[item])
                    Button("Remove") {
                        globalString1.removeFirst()
                    }
                    Spacer()
                }
            }
        }
        }
}
