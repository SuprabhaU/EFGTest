//
//  ContentView.swift
//  EDGTest
//
//  Created by Suprabha Dhavan on 17/05/23.
//

import SwiftUI
import CoreData
class GlobalString: ObservableObject {
  @Published var usedWords = [String]()

}
struct ContentView: View {
    var dish: Vehicle
    @StateObject var globalString = GlobalString()
    
      var body: some View {
          TabView {

                      ProductView()
                          .tabItem {
                              Label("Product", systemImage: "square.and.pencil")
                          }
              FavView(globalString1: $globalString.usedWords)
                  .tabItem {
                      Label("Favourite", systemImage: "square.and.pencil")
                  }
                  }
      }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(dish: menuItems[0])
    }
}
