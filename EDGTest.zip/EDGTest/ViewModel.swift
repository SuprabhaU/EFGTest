//
//  ViewModel.swift
//  EDGTest
//
//  Created by Suprabha Dhavan on 17/05/23.
//

import Foundation
import SwiftUI
struct Vehicle: Decodable, Identifiable {
    var id: String
//    var citrusId: String
    var title: String
    var imageURL: String
    var price: Double
//    var value: String
    var ratingCount: Double
}

extension Vehicle {
    var image: Image {
        RestaurantImageStore.shared.image(name: imageURL)
    }
}
class ViewModel: ObservableObject {
    @Published private(set) var vehicle: Vehicle?
    
    init() {
        Task.init {
            await fetchData()
        }
    }
    
    func fetchData() async {
        do {
            guard let url = URL(string: "https://run.mocky.io/v3/2f06b453-8375-43cf-861a-06e95a951328") else { fatalError("Missing URL") }
            
            let urlRequest = URLRequest(url: url)
            
            let (data, response) = try await URLSession.shared.data(for: urlRequest)
            
            guard (response as? HTTPURLResponse)?.statusCode == 200 else { fatalError("Error while fetching data") }
            
            let decoder = JSONDecoder()
           // decoder.keyDecodingStrategy = .convertFromSnakeCase
            let decodedData = try decoder.decode(Vehicle.self, from: data)
            
            DispatchQueue.main.async {
                self.vehicle = decodedData
            }
            
        } catch {
            print("Error fetching data from Pexels: \(error)")
        }
    }
}
